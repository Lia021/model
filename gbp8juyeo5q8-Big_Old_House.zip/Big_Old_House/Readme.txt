Here is another lowpoly building.

Textures: diffuse, specular and normalmap = 2048 px.

Animated No
Rigged Yes
Lowpoly (game-ready) Yes
Geometry Polygon mesh
Polygons 671
Vertices 2,366
Textures Yes
Materials Yes
UV Mapping Yes
Unwrapped UVs Non-overlapping

Demo Video: https://www.youtube.com/watch?v=YxVIy1kfyMk
3d-Preview on Sketchfab : https://sketchfab.com/models/dpCA3StfXM03WZRqwZglHiv4fj6

Homepage: http://3dartdh.wordpress.com/
Contact me: https://3dartdh.wordpress.com/contact/
Sketchfab: https://sketchfab.com/dennish2010
YouTube: https://www.youtube.com/user/DennisH2010

